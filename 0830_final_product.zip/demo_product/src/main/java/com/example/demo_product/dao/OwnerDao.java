package com.example.demo_product.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo_product.vo.OwnerVo;
import com.example.demo_product.vo.ProductVo;

@Mapper
public interface OwnerDao {

    public List<OwnerVo> selectList();

    public List<ProductVo> selectOne();
 

    public OwnerVo selectOneFromIdx(int o_idx);

 
    public ProductVo selectOneIdx(int p_idx);


    public ProductVo selectOne(int p_idx);

	
	public OwnerVo selectOneFromId(String o_id);

    public int insert(OwnerVo vo);

	public int update(OwnerVo vo) ;

	public int delete(int o_idx);
}
