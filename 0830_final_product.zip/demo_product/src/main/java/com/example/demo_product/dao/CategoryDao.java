package com.example.demo_product.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo_product.vo.CategoryVo;
import com.example.demo_product.vo.ProductVo;


@Mapper
public interface CategoryDao {
    
      public List<CategoryVo> selectList();

      public List<CategoryVo> selectTypeList(int p_idx);

     



        
}
