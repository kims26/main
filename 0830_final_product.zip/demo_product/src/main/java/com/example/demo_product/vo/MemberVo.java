package com.example.demo_product.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MemberVo {

	int    mem_idx;
	String mem_name;
	String mem_id;
	String mem_pwd;
	String mem_addr;
	String mem_type;
	String mem_zipcode;
	String mem_regdate;
	String mem_tel;
    String mem_ip;
	
	
	

    
	
	
}
