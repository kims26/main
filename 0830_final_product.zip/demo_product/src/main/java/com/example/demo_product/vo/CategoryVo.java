package com.example.demo_product.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryVo {
    
    int category_idx;
    int category_code;
    int p_idx;
    String category_name;
}
