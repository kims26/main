package com.example.demo_product.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo_product.dao.CategoryDao;
import com.example.demo_product.dao.ProductDao;
import com.example.demo_product.vo.CategoryVo;

@Controller
public class CategoryController {


    CategoryDao categoryDao;
	CategoryVo CategoryVo;

	ProductDao productDao;

	@Autowired
		public CategoryController(CategoryDao categoryDao) {
			this.categoryDao = categoryDao;
		}
    
     @RequestMapping("/category/a_type_list.do")
		public String atypelist(int p_idx,Model model){
			

		List<CategoryVo> list =categoryDao.selectTypeList(p_idx);

		model.addAttribute("list", list);

		return"category/a_type_category";
	}

	@RequestMapping("/category/b_type_list.do")
		public String btypelist(int p_idx,Model model){

		List<CategoryVo> list =categoryDao.selectTypeList(p_idx);

		model.addAttribute("list", list);

		return"category/b_type_category";
	}

	@RequestMapping("/category/c_type_list.do")
		public String ctypelist(int p_idx,Model model){

		List<CategoryVo> list =categoryDao.selectTypeList(p_idx);

		model.addAttribute("list", list);

		return"category/c_type_category";
	}
	

}
